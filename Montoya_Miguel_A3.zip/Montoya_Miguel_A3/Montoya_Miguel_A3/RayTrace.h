#pragma once

#ifndef RAYTRACE_H
#define RAYTRACE_H

void displayFunction();
void resizeFunction(int width, int height);
void mouseFunction(int button, int state, int x, int y);
void idleFunction();

#endif
