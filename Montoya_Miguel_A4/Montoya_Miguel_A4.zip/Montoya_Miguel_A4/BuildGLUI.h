#pragma once

#ifndef BUILDGLUI
#define BUILDGLUI

void buildGLUI(int windowId);

#endif